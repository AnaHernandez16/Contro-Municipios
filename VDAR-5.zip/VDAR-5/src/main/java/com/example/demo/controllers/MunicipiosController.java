package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Municipio;
import com.example.demo.service.MunicipiosService;

@RestController
@RequestMapping("/api")
public class MunicipiosController {
	
	@Autowired
	private MunicipiosService municipiosService;
	
	@GetMapping("/municipio/{id}")
	public Municipio show(@PathVariable String id) {
		return municipiosService.findMunicipioById(id);
	}
	
	@PostMapping("/save")
	public Municipio create(@RequestBody Municipio municipio){
		return municipiosService.addMunicipio(municipio);
	}
	
	@PutMapping("/update/{id}")
	public Municipio update (@RequestBody Municipio municipio, @PathVariable String id){
		
		Municipio municipioActual = municipiosService.findMunicipioById(id);
		
		municipioActual.setNombre_municipio(municipio.getNombre_municipio());
		municipioActual.setEstado(municipio.getEstado());
		municipioActual.setNumero_habitantes(municipio.getNumero_habitantes());
		municipioActual.setNumero_viviendas(municipio.getNumero_viviendas());
		municipioActual.setGobernador(municipio.getGobernador());
		municipioActual.setPIB(municipio.getPIB());
		
		return municipiosService.addMunicipio(municipioActual);
	}
	
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable String id) {
		municipiosService.delete(id);
	}

}
