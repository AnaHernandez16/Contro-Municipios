package com.example.demo.service;

import com.example.demo.entity.Casa;

public interface CasasService {

	public abstract Casa addCasa(Casa casa);
}
