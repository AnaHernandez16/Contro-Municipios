package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Municipio;

public interface MunicipiosService {

	public abstract Municipio addMunicipio(Municipio municipio);
	List<Municipio> getMunicipio();
	Municipio findMunicipioById(String id);
	void delete(String id);
}
